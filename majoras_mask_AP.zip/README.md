Archipelago Majora's Mask tracker pack for [PopTracker](https://github.com/black-sliver/PopTracker/) with Autotracking.

PopTracker v0.27.0 or higher is recommended.

![Screenshot of the pack](images/preview.png)

## Installation

Just download the lastest build or source and put in your packs folder (zipped or unzipped does not matter.)

##More Info

This will be a work in progress while the AP integration is developed, and will be designed to follow AP's logic, not necessarily matching standalone or higher difficulties at this time. If you encounter any bugs, or have any questions regarding the tracker, feel free to ask or ping me anytime (@Seto10987)