
Tracker:AddLocations("locations/clock_town.json")
Tracker:AddLocations("locations/dungeons.json")
Tracker:AddLocations("locations/ikana_canyon.json")
Tracker:AddLocations("locations/romani_ranch.json")
Tracker:AddLocations("locations/southern_swamp.json")
Tracker:AddLocations("locations/swamp_spider_house.json")
Tracker:AddLocations("locations/termina.json")
Tracker:AddLocations("locations/woodfall_temple.json")